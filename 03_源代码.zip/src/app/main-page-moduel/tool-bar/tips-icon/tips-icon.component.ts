import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-tips-icon',
  templateUrl: './tips-icon.component.html',
  styleUrls: ['./tips-icon.component.css']
})
export class TipsIconComponent implements OnInit {
  ngOnInit() {
  }

}
